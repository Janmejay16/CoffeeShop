import os
from flask import Flask, request, jsonify, abort
from sqlalchemy import exc
import json
from flask_cors import CORS

from .database.models import db_drop_and_create_all, setup_db, Drink
from .auth.auth import AuthError, requires_auth

app = Flask(__name__)
setup_db(app)
CORS(app)

'''
@TODO uncomment the following line to initialize the datbase
!! NOTE THIS WILL DROP ALL RECORDS AND START YOUR DB FROM SCRATCH
!! NOTE THIS MUST BE UNCOMMENTED ON FIRST RUN
'''

@app.after_request
def after_request(response):
    header = response.headers
    header['Access-Control-Allow-Origin'] = '*'
    header['Access-Control-Allow-Headers'] = 'Authorization, Content-Type, true'
    header['Access-Control-Allow-Methods'] = 'POST,GET,PUT,DELETE,PATCH,OPTIONS'
    return response

#db_drop_and_create_all()

## ROUTES

@app.route('/drinks')
def GetDrinks():
    drinks = Drink.query.all()
    all_drinks = [drink.long for drink in drinks]
    return jsonify({
        "success" : True,
        "drinks" : all_drinks
        })


@app.route('/drinks-detail')
@requires_auth('get:drinks-detail')
def GetDrinksDetails(token):
    drinks = Drink.query.all()
    all_drinks = [drink.long for drink in drinks]
    return jsonify({
        "success" : True,
        "drinks" : all_drinks
        })


@app.route('/drinks', methods=['POST'])
@requires_auth('post:drinks')
def AddDrink(token):
    if request.data:
        details = request.get_json()
        title = details.get('title', None)
        recipe = details.get('recipe', None)
        drink = Drink(title=title, recipe=json.dumps(recipe))
        Drink.insert(drink)

        newly_added_drink = Drink.query.filter_by(id=drink.id).first()

        return jsonify({
            'success': True,
            'drinks': [newly_added_drink.long()]
        })
    else:
        abort(422)


@app.route('/drinks/<int:drink_id>', methods=['PATCH'])
@requires_auth('patch:drinks')
def ModifyDrink(token, drink_id):
    details = request.get_json()
    title = details.get('title', None)
    recipe = details.get('recipe', None)

    try:
        drink = Drink.query.filter_by(id=drink_id).one_or_none()
        if drink is None:
            abort(404)

        if title is None:
            abort(400)
        
        if title is not None:
            drink.title = title

        if recipe is not None:
            drink.recipe = json.dumps(recipe)

        drink.update()

        modified_drink = Drink.query.filter_by(id=drink_id).first()

        return jsonify({
            'success': True,
            'drinks': [modified_drink.long()]
        })
    except:
        abort(422)

@app.route('/drinks/<int:drink_id>', methods=['DELETE'])
@requires_auth('delete:drinks')
def DeleteDrink(token, drink_id):
    try:
        drink = Drink.query.filter_by(id=drink_id).one_or_none()
        if drink is None:
            abort(404)

        drink.delete()
        return jsonify({
            'success': True,
            'deleted': drink_id
        })
    except:
        abort(422)

## Error Handling

#422 Error for unprocessable entity
@app.errorhandler(422)
def unprocessable_entity(error):
    return jsonify({
        "success": False, 
        "error": 422,
        "message": "Unprocessable Entity"
        }), 422


#Not Found Error 404
@app.errorhandler(404)
def not_found_error(error):
    return jsonify({
        "success": False, 
        "error": 404,
        "message": "Resource Not Found"
        }), 404


#Unauthorized error 401
@app.errorhandler(401)
def unauthorized(error):
    return jsonify({
        "success": False,
        "error":401,
        "message":"Unauthorized"
        }), 401

#Method Not Allowed error 405
@app.errorhandler(405)
def not_allowed(error):
    return jsonify({
        "success": False,
        "error":405,
        "message":"Method Not Allowed"
        }), 405


#Internal Server Error 500
@app.errorhandler(500)
def server_error(error):
    return jsonify({
        "success": False,
        "error":500,
        "message":"Error in Internal Server"
        }), 500

if __name__ == '__main__':
    app.run(debug=True)
